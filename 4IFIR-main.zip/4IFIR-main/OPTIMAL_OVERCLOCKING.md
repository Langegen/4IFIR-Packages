## Optimal overclocking for different games, higher settings only increases power consumption

1. [The Elder Scrolls V Skyrim](#The-Elder-Scrolls-V-Skyrim)

### The Elder Scrolls V Skyrim
**60 FPS**
* **CPU:** 1122 MHz
* **GPU:** 844 MHz (4IFIR Optimized)
* **MEMORY:** 2666 MHz (4IFIR Krackenized)

### The list will expand, if there is a desire to help the community, I will be glad to pull requests ;)